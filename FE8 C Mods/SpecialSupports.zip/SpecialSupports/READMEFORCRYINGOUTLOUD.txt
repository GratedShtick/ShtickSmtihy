Made by GratedShtick. F2U/F2E

Install by using the Installer.event file, but ensure that the following 2 prerequisites are fulfilled.
1) You put where the EAstdlib filepath is on your machine in the "#include "EAstdlib.event"" section by putting the filepath within the inner set of quotations.
2) the SpecialSupportPartners.lyn.event file is in the same file as the installer.

Installer.event has the predetermined special supports, but I based those off of FE8's vanilla cast. Just follow the structure given with whatever support pairs you already have and it should work fine. By default, this only allows for 3 special pairs per unit.