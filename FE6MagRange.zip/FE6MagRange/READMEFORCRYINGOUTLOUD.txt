Made by GratedShtick. F2U/F2E.

Install by installing the EA file into the ROM.