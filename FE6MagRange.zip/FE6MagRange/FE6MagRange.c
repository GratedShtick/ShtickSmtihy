#include "C_Code.h"
int GetUnitMagBy2Range(struct Unit* unit) {
    if (unit->pCharacterData->number == CHARACTER_FOMORTIIS) {
        return GetItemMaxRange(ITEM_NIGHTMARE);
    } else {
        int result = 5+(GetUnitPower(unit) / 2);
        return result;
    }
}