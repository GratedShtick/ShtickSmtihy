#include "C_Code.h"
extern u8 PunisherWeapons[];
int IsWeaponPunisher (int itemID) {
	itemID &=0xFF;
	const u8* list = PunisherWeapons;
	while (*list) {
		if (itemID == *list) {
			return true;
		}
		list++;
	}
	return false;
}
void ComputeBattleUnitAttack(struct BattleUnit* attacker, struct BattleUnit* defender) {
    short attack;
    attacker->battleAttack = GetItemMight(attacker->weapon) + attacker->wTriangleDmgBonus;
    attack = attacker->battleAttack;
	int itemID = attacker->weapon;
    if (IsUnitEffectiveAgainst(&attacker->unit, &defender->unit) == TRUE)
        attack = attacker->battleAttack * 3;
    if (IsItemEffectiveAgainst(attacker->weapon, &defender->unit) == TRUE) {
        attack = attacker->battleAttack;
        switch (GetItemIndex(attacker->weapon)) {
        case ITEM_SWORD_AUDHULMA:
        case ITEM_LANCE_VIDOFNIR:
        case ITEM_AXE_GARM:
        case ITEM_BOW_NIDHOGG:
        case ITEM_ANIMA_EXCALIBUR:
        case ITEM_LIGHT_IVALDI:
        case ITEM_SWORD_SIEGLINDE:
        case ITEM_LANCE_SIEGMUND:
            attack *= 2;
            break;
        default:
            attack *= 3;
            break;
        } // switch (GetItemIndex(attacker->weapon))
	}
	if ((attacker->wTriangleHitBonus > 0) && IsWeaponPunisher(itemID)){
		attack *=3;
	}
	attacker->battleAttack = attack;
    attacker->battleAttack += attacker->unit.pow;
    if (GetItemIndex(attacker->weapon) == ITEM_MONSTER_STONE)
        attacker->battleAttack = 0;
}
void InitBattleForecastBattleStats(struct BattleForecastProc * proc) {
    struct BattleUnit * buFirst;
    struct BattleUnit * buSecond;
    int usesA = GetItemUses(gBattleActor.weaponBefore);
    int usesB = GetItemUses(gBattleTarget.weaponBefore);
    s8 followUp = BattleGetFollowUpOrder(&buFirst, &buSecond);
    proc->hitCountA = 0;
    proc->isEffectiveA = 0;
    if ((gBattleActor.weapon != 0) || (gBattleActor.weaponBroke)) {
        BattleForecastHitCountUpdate(&gBattleActor, (u8*)&proc->hitCountA, &usesA);
        if ((followUp != 0) && (buFirst == &gBattleActor)) {
            BattleForecastHitCountUpdate(buFirst, (u8*)&proc->hitCountA, &usesA);
        }
        if (IsUnitEffectiveAgainst(&gBattleActor.unit, &gBattleTarget.unit) != 0) {
            proc->isEffectiveA = 1;
        }
        if (IsItemEffectiveAgainst(gBattleActor.weaponBefore, &gBattleTarget.unit) != 0) {
            proc->isEffectiveA = 1;
        }
        if ((gBattleActor.wTriangleHitBonus > 0) && (gBattleActor.weaponAttributes & IA_REVERTTRIANGLE) != 0) {
            proc->isEffectiveA = 1;
        }
		if ((gBattleActor.wTriangleHitBonus > 0) && IsWeaponPunisher(gBattleActor.weapon)) { ///won't use itemID, but it compiles with gBattleActor/gBattleTarget
			proc->isEffectiveA = 1;
		}
    }
    proc->hitCountB = 0;
    proc->isEffectiveB = 0;
    if ((gBattleTarget.weapon != 0) || (gBattleTarget.weaponBroke)) {
        BattleForecastHitCountUpdate(&gBattleTarget, (u8*)&proc->hitCountB, &usesB);
        if ((followUp != 0) && (buFirst == &gBattleTarget)) {
            BattleForecastHitCountUpdate(buFirst, (u8*)&proc->hitCountB, &usesB);
        }
        if (IsUnitEffectiveAgainst(&gBattleTarget.unit, &gBattleActor.unit) != 0) {
            proc->isEffectiveB = 1;
        }
        if (IsItemEffectiveAgainst(gBattleTarget.weaponBefore, &gBattleActor.unit) != 0) {
            proc->isEffectiveB = 1;
        }
        if ((gBattleTarget.wTriangleHitBonus > 0) && (gBattleTarget.weaponAttributes & IA_REVERTTRIANGLE) != 0) {
            proc->isEffectiveB = 1;
        }
		if((gBattleTarget.wTriangleHitBonus > 0) && IsWeaponPunisher(gBattleTarget.weapon)) {
			proc->isEffectiveB = 1;
		}
	}
}