Made by GratedShtick. F2U/F2E.

Install by using the Installer.event file, but ensure that the following 2 prerequisites are fulfilled.
1) You put where the EAstdlib filepath is on your machine in the "#include "EAstdlib.event"" section by putting the filepath within the inner set of quotations.
2) the "WTPunishers.lyn.event" file is in the same file as the installer.

Installer.event has the predetermined weapons affected, but follow the structure given with whatever weapons you want and it should work fine.