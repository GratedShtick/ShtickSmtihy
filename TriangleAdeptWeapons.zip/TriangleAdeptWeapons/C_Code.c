#include "C_Code.h"
extern u8 TriangleAdeptWeapons[];
int IsWeaponTriangleAdept (int itemID) {
	itemID &=0xFF;
	const u8* list = TriangleAdeptWeapons;
	while (*list) {
		if (itemID == *list) {
			return true;
		}
		list++;
	}
	return false;
}
struct WeaponTriangleRule {
    s8 attackerWeaponType;
    s8 defenderWeaponType;
    s8 hitBonus;
    s8 atkBonus;
};
static const struct WeaponTriangleRule sWeaponTriangleRules[] = {
    { ITYPE_SWORD, ITYPE_LANCE, -15, -1 },
    { ITYPE_SWORD, ITYPE_AXE,   +15, +1 },
    { ITYPE_LANCE, ITYPE_AXE,   -15, -1 },
    { ITYPE_LANCE, ITYPE_SWORD, +15, +1 },
    { ITYPE_AXE,   ITYPE_SWORD, -15, -1 },
    { ITYPE_AXE,   ITYPE_LANCE, +15, +1 },
    { ITYPE_ANIMA, ITYPE_DARK,  -15, -1 },
    { ITYPE_ANIMA, ITYPE_LIGHT, +15, +1 },
    { ITYPE_LIGHT, ITYPE_ANIMA, -15, -1 },
    { ITYPE_LIGHT, ITYPE_DARK,  +15, +1 },
    { ITYPE_DARK,  ITYPE_LIGHT, -15, -1 },
    { ITYPE_DARK,  ITYPE_ANIMA, +15, +1 },
    { -1 },
};
void BattleApplyWeaponTriangleEffect(struct BattleUnit* attacker, struct BattleUnit* defender) {
	int itemID_attacker = attacker->weapon;
	int itemID_defender = defender->weapon;
    const struct WeaponTriangleRule* it;
    for (it = sWeaponTriangleRules; it->attackerWeaponType >= 0; ++it) {
        if ((attacker->weaponType == it->attackerWeaponType) && (defender->weaponType == it->defenderWeaponType)) {
            attacker->wTriangleHitBonus = it->hitBonus;
            attacker->wTriangleDmgBonus = it->atkBonus;
            defender->wTriangleHitBonus = -it->hitBonus;
            defender->wTriangleDmgBonus = -it->atkBonus;
			if (IsWeaponTriangleAdept(itemID_attacker) | IsWeaponTriangleAdept(itemID_defender)) {
				attacker->wTriangleHitBonus = (attacker->wTriangleHitBonus * 4);
				attacker->wTriangleDmgBonus = (attacker->wTriangleDmgBonus * 4);
				defender->wTriangleHitBonus = (defender->wTriangleHitBonus * 4) ;
				defender->wTriangleDmgBonus = (defender->wTriangleDmgBonus * 4) ;
			}
            break;
        }
    }
    if (attacker->weaponAttributes & IA_REVERTTRIANGLE)
        BattleApplyReaverEffect(attacker, defender);
    if (defender->weaponAttributes & IA_REVERTTRIANGLE)
        BattleApplyReaverEffect(attacker, defender);
}